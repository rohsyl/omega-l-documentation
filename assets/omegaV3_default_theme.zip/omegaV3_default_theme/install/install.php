<?php
use Omega\Library\Entity\ModuleArea;

/*********************************************************************
 *
 *       DEFAULT THEME INSTALLATION FILE FOR OmegaCMSv3
 *
/*********************************************************************/
// The name of your theme (this value must be the same as the name of the theme's directory) ..
$name = "omegav3_default_theme";
// The title of your theme ...
$title = "DEFAULT Theme by OmegaCMS Team";
// A little description ...
$description = "A theme developped by OmegaCMS Dev Team";
// And your website ...
$website = "http://localhost";
$colors = array(
    '#000000', '#FFFFFF'
);
//Custom action that must be executed after the installation
function post_install() {
    // Ici nous avons la création d'un module area.
}
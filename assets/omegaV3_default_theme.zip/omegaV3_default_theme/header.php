<?php
    use Omega\Library\Util\OmegaUtil;
    use Omega\Library\Entity\Entity;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <?php OmegaUtil::renderMeta() ?>
    <title><?php echo Entity::Site()->name ?> - <?php echo Entity::Page()->title ?></title>
    <link href="<?= Entity::Site()->template_directory_uri ?>/css/styles.css" rel="stylesheet">
    <script src="<?= Entity::Site()->template_directory_uri ?>/js/scripts.js"></script>
    <?php Entity::Page()->RenderCssTheme() ?>
    <?php OmegaUtil::renderDependencies() ?>
</head>
<?php
    use Omega\Library\Entity\Entity;
    use Omega\Library\Entity\ModuleArea;
?>
    <footer>
        <!-- Affichage du modulearea -->
    </footer>
</body>
</html>